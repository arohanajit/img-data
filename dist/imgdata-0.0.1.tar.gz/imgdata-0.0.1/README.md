# img-data
PyPi package to make image datasets
